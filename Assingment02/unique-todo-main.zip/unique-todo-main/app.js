const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session'); 
const passport = require('passport'); 
var logger = require('morgan'); 
const hbs = require('hbs');
const path = require('path');
const { initializePassport } = require('./functions/passport');
const bodyParser = require('body-parser');
var methodOverride = require('method-override') 
const app = express();
const {verifyUser} = require('./functions/passport')

// Load environment variables
require('dotenv').config();

// Connect to MongoDB
mongoose.connect('mongodb+srv://nisargp2131:ZyLM3aKdBQcU7VUT@cluster0.x1tauxm.mongodb.net/project?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('Connected to MongoDB');
})
.catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});
 ;

// initilizig passport
initializePassport(passport);


 
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride('_method'));
app.use(session({
  secret: "secret", resave: false, saveUninitialized: false
}));


app.use(passport.initialize());
app.use(passport.session());
app.use(express.static(path.join(__dirname, 'public')));

// Set up HBS view engine
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));
hbs.registerPartials(path.join(__dirname, 'views/partials'));

app.use(bodyParser.json());

// Routes
const authRoutes = require('./controllers/authController');
app.use('/', authRoutes);

const dashboardRoutes = require('./controllers/dashboardController');
app.use('/', verifyUser, dashboardRoutes);

const notesRoutes = require('./controllers/noteController.js');
app.use('/notes', notesRoutes);

// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
