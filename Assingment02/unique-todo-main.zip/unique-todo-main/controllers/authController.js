const express = require('express');
const passport = require('passport');
const router = express.Router();
const bcrypt = require('bcrypt');
// Import User model
const Note = require('../models/Note');
const User = require('../models/User');
 
router.get('/', async function (req, res, next) {
  const users = await Note.find();
  // console.log(users);
  res.render('index', { notesList: users });
});

router.post('/register', async (req, res) => { 
  try {
    const { username, email,phone, password } = req.body;

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10); // 10 is the number of salt rounds

    const newUser = new User({ username, email, password: hashedPassword,phone });
    await newUser.save();
   res.redirect('/register');
    // res.status(201).json({ message: 'User registered successfully' });
   res.re
  } catch (error) {
    console.log(error)
    res.status(500).json({ message: error });
  }
});

// Login route
router.get('/login', (req, res) => {
  
  res.render('login');  // Specify the layout
});

router.get('/register', (req, res) => {
  
  res.render('register');  // Specify the layout
});

router.post('/login', passport.authenticate("local", { successRedirect: '/dashboard' }), function (req, res, next) {
});


  // Logout route
  router.get('/logout', (req, res) => {
    req.logout();
    res.redirect('/');
  });

module.exports = router;
