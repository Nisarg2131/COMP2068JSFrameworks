const express = require('express');
const passport = require('passport');
const router = express.Router();
const bcrypt = require('bcrypt');

router.get('/dashboard', (req, res) => {
  
    res.render('dashboard');  // Specify the layout
  });
  

  module.exports = router;  
