const express = require('express');
const router = express.Router();
const Note = require('../models/Note');

// Create a new note (GET)
router.get('/create', (req, res) => {
  res.render('note/create');
});

// Create a new note (POST)
router.post('/', async (req, res) => {
  try {
    const { title, content } = req.body;
    const newNote = new Note({ title, content });
    await newNote.save();
    res.redirect('/notes');
  } catch (error) {
    res.status(500).json({ message: 'An error occurred' });
  }
});

// Read all notes
router.get('/', async (req, res) => {
  try {
    const notes = await Note.find();
    res.render('note/read', { notes });
  } catch (error) {
    res.status(500).json({ message: 'An error occurred' });
  }
});

// Update a note (GET)
router.get('/edit/:id', async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    res.render('note/update', { note });
  } catch (error) {
    res.status(500).json({ message: 'An error occurred' });
  }
});

// Update a note (POST)
router.post('/:id', async (req, res) => {
  try {
    const { title, content } = req.body;
    const updatedNote = await Note.findByIdAndUpdate(req.params.id, { title, content }, { new: true });
    res.redirect('/notes');
  } catch (error) {
    res.status(500).json({ message: 'An error occurred' });
  }
});

// Delete a note (GET)
router.get('/delete/:id', async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    res.render('note/delete', { note });
  } catch (error) {
    res.status(500).json({ message: 'An error occurred' });
  }
});

// Delete a note (POST)
router.post('/delete/:id', async (req, res) => {
  try {
    await Note.findByIdAndRemove(req.params.id);
    res.redirect('/notes');
  } catch (error) {
    res.status(500).json({ message: 'An error occurred' });
  }
});

module.exports = router;
